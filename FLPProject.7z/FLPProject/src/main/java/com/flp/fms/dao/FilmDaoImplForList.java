package com.flp.fms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.flp.ems.domain.Actor;
import com.flp.ems.domain.Film;

public class FilmDaoImplForList implements IFilmDao
{
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("gupta");
	EntityManager em=emf.createEntityManager();
	
	public void addFilm(Film film) 
	{
		em.getTransaction().begin();
		em.persist(film);
		em.getTransaction().commit();
	}
	public Film modifyFilm(Film film)
	{
		em.getTransaction().begin();
		em.merge(film);
		em.getTransaction().commit();
		return film;
	}
	public boolean removeFilm(int film_id)
	{
		Film film=searchFilm(film_id);
		if(film!=null)
		{
			em.remove(film);
			return true;
		}
		return false;
	}
	public Film searchFilm(int film_id) 
	{
		return em.find(Film.class, film_id);
	}
	public List<Film> getAllFilm()
	{
		TypedQuery<Film> query=em.createQuery("Select f from Film f",Film.class);
		return query.getResultList();
	}
}

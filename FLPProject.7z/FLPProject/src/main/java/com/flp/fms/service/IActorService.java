package com.flp.fms.service;

import java.util.List;

import com.flp.ems.domain.Actor;

public interface IActorService
{
	abstract Actor addActor(String firstname, String lastname);
	abstract Actor modifyActor(int actor_id, String firstname, String lastname);
	abstract boolean removeActor(int actor_id);
	abstract Actor searchActor(int actor_id);
	abstract List<Actor> getAllActor();
	
}

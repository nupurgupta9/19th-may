package com.flp.fms.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.flp.ems.domain.Actor;

public class ActorDaoImplForList implements IActorDao 
{
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("gupta");
	EntityManager em=emf.createEntityManager();
	
	public Actor addActor(String first_name, String last_name)
	{
		Actor actor=findActorByName(first_name, last_name);
		if(actor == null)
		{
			em.getTransaction().begin();
			em.persist(actor);
			em.getTransaction().commit();
		}
		return actor;
	}
	private Actor findActorByName(String first_name, String last_name) 
	{
		
		return em.find(Actor.class, first_name);
    }
	
	public Actor modifyActor(int actor_id)
	{
		Actor actor=searchActor(actor_id);
		if(actor!=null)
		{
		em.getTransaction().begin();
		em.merge(actor);
		em.getTransaction().commit();
		}
		return actor;
	}
	public boolean removeActor(int actor_id)
	{
		Actor actor=searchActor(actor_id);
		if(actor!=null)
		{
			em.remove(actor);
			return true;
		}
		return false;
	}
	public Actor searchActor(int actor_id)
	{
		return em.find(Actor.class, actor_id);
	}

	public List<Actor> getAllActor() 
	{
		TypedQuery<Actor> query=em.createQuery("Select a from Actor a",Actor.class);
		return query.getResultList();
	}
}

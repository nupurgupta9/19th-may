package com.flp.fms.view;

import java.text.ParseException;


import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.flp.ems.domain.Actor;
import com.flp.ems.domain.Film;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class UserInteraction
{
	private static Scanner scn=new Scanner(System.in);
	IFilmService filmService;
	IActorService actorService;
	public UserInteraction()
	{
		filmService=new FilmServiceImpl();
		actorService=new ActorServiceImpl();
	}
	
	//1
	public void addFilm() throws ParseException
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		Map<Integer,Object> filmList=new HashMap();
		System.out.println("Enter film title : ");
		filmList.put(1,(scn.next()));
		System.out.println("Enter description : ");
		filmList.put(2,scn.next());
		System.out.println("Enter release year : ");
		filmList.put(3,dateFormat.parse(scn.next()));
		System.out.println("Enter rental duration : ");
		filmList.put(4,scn.nextInt());
		System.out.println("Enter rental rate : ");
		filmList.put(5,scn.nextInt());
		System.out.println("Enter length : ");
		filmList.put(6,scn.nextInt());
		System.out.println("Enter replacement cost : ");
		filmList.put(7,scn.nextInt());
		System.out.println("Enter rating : ");
		filmList.put(8,scn.nextInt());
		System.out.println("Enter special features : ");
		filmList.put(9,scn.next());
		System.out.println("Enter language : ");
		filmList.put(10,scn.next());
		System.out.println("Enter category : ");
		filmList.put(11,scn.next());
		System.out.println("Enter number of actors : ");
		int noOfActors=scn.nextInt();
		for(int i=0;i<noOfActors;i++)
		{  
		Map<Integer,Object> actorDetails=new HashMap();
		System.out.println("Enter firstname of "+(i+1)+" actor : ");
		actorDetails.put(1,scn.next());
		System.out.println("Enter lastname of "+(i+1)+" actor : ");
		actorDetails.put(2,scn.next());
		filmList.put(12,actorDetails);
		}
		filmService.addFilm(filmList);
	}
	//2
	public void modifyFilm()
	{
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
				Map<Integer,Object> filmList=new HashMap();
				System.out.println("enter the film id that should be modified");
				filmList.put(1,(scn.nextInt()));
				System.out.println("enter film title");
				filmList.put(2,(scn.next()));
				System.out.println("enter description");
				filmList.put(3,scn.next());
				System.out.println("enter release year");
				try {
					filmList.put(4,dateFormat.parse(scn.next()));
				} catch (ParseException e) {
					e.printStackTrace();
				}
				System.out.println("enter rental duration");
				filmList.put(5,scn.nextInt());
				System.out.println("enter rental rate");
				filmList.put(6,scn.nextInt());
				System.out.println("enter length");
				filmList.put(7,scn.nextInt());
				System.out.println("enter replacementcost");
				filmList.put(8,scn.nextInt());
				System.out.println("enter rating");
				filmList.put(9,scn.nextInt());
				System.out.println("enter special features");
				filmList.put(10,scn.next());
				System.out.println("enter language");
				filmList.put(11,scn.next());
				System.out.println("enter category");
				filmList.put(12,scn.next());
				System.out.println("enter number of actors");
				int noOfActors=scn.nextInt();
				System.out.println("enter number of actors");
				for(int i=0;i<=noOfActors;i++)
				{  
				Map<Integer,Object> actorDetails=new HashMap();
				System.out.println("enter firstname of actor");
				actorDetails.put(1,scn.next());
				System.out.println("enter lastname of actor");
				actorDetails.put(2,scn.next());
				filmList.put(13,actorDetails);
				}
		 System.out.println(filmService.modifyFilm(filmList));
	}
	//3
	public void removeFilm()
	{
			System.out.println("Enter the film id to remove");
			int film_id=scn.nextInt();
			if(filmService.removeFilm(film_id))
			{
				System.out.println("film Successfully removed");
			}
			else
			{
				System.out.println("film Not Found");
			}
	}
	//4
	public void searchFilm()
	{
			System.out.println("search film by film id");
			short film_id=scn.nextShort();
			Film film=filmService.searchFilm(film_id);
			if(film !=null)
			{
				System.out.println("found "+film);
			}
			else
				System.out.println("not found");
	}	
	 //5
		public void getAllFilm()
		{
			List<Film> films=filmService.getAllFilm();
			System.out.println("all films are "+films);
		}
	//6
		public Actor addActor()
		{
			//Actor actor=new Actor();
			System.out.println("enter first name");
			String firstname=scn.next();
			System.out.println("enter last name");
			String lastname=scn.next();
			return actorService.addActor(firstname,lastname);
		}
	//7
		public void modifyActor()
		{
			System.out.println("enter actor id that shoulb be modified");
			int actor_id=scn.nextInt();
			System.out.println("enter first name");
			String firstname=scn.next();
			System.out.println("enter last name");
			String lastname=scn.next();
			System.out.println("modified actor details are "+actorService.modifyActor(actor_id,firstname,lastname));
		}
	//8
		public void searchActor()
		{    
			System.out.println("enter the actor id that should be retrievd");
			int actor_id=scn.nextInt();
			Actor actors=actorService.searchActor(actor_id);
			if(actors !=null)
			{
				System.out.println("Found "+actors);
			}
			else
			{
				System.out.println("Not Found");
			}
		}
	//9	
		public void removeActor()
		{
			System.out.println("enter actor id that should be removed");
			int actor_id=scn.nextInt();
			if(actorService.removeActor(actor_id))
			{
				System.out.println("actor details removed sucessfully");
			}
			else System.out.println("cannot be removed");
		}	
	//10
		public void getAllActor()
		{
			List<Actor> actors=actorService.getAllActor();
			System.out.println("all actor details "+actors);
		}
	//11	
		public void exit(){
			System.exit(0);
		}
	
	}
		

	


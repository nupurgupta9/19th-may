package com.flp.fms.service;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.flp.ems.domain.Film;


public interface IFilmService 
{
	abstract void addFilm(Map<Integer, Object> filmList)  throws ParseException;
	abstract boolean modifyFilm(Map<Integer, Object> filmList);
	abstract boolean removeFilm(int film_id);
	abstract Film searchFilm(int film_id);
	abstract List<Film> getAllFilm();
	
}

package com.flp.fms.service;

import java.text.ParseException;


import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.ems.domain.Actor;
import com.flp.ems.domain.Category;
import com.flp.ems.domain.Film;
import com.flp.ems.domain.Language;
import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;

public class FilmServiceImpl implements IFilmService
{
   IFilmDao filmDao;
   public FilmServiceImpl()
   {
	filmDao=new FilmDaoImplForList();
   }
   
   
    public void addFilm(Map<Integer, Object> filmList) throws ParseException 
    {
    	Film film=new Film();
		film.setTitle((String) filmList.get(1));
		film.setDiscription((String) filmList.get(2));
		film.setRelease_year((Date)filmList.get(3));
		film.setRental_duration((Integer) filmList.get(4));
		film.setRental_rate((Integer) filmList.get(5));
	    film.setLength((Integer) filmList.get(6));
		film.setReplacement_cost((Integer) filmList.get(7));
		film.setRating((Integer) filmList.get(8));
		film.setSpecial_features((String)filmList.get(9));
		Language language= new Language();
		language.setName((String)filmList.get(10));
		film.setLanguage(language);
		Category category= new Category();
		category.setName((String) filmList.get(11));
		film.setCategory(category);
		
		for(int i=12;i<filmList.size();i++)
		{
			Actor actor=new Actor();
			Map<Integer,Object> actorDetails=(Map) filmList.get(i);
			actor.setFirst_name((String) actorDetails.get(1));
			actor.setLast_name((String) actorDetails.get(2));
			film.getActor().add(actor);
		}
		filmDao.addFilm(film);
	}
	public boolean modifyFilm(Map<Integer, Object> filmList)
	{
		Film film=filmDao.searchFilm((Integer)filmList.get(1));
		if(film!=null)
		{
		film.setTitle((String) filmList.get(2));
		film.setDiscription((String) filmList.get(3));
		film.setRelease_year((Date)filmList.get(4));
		film.setRental_duration((Integer) filmList.get(5));
		film.setRental_rate((Integer) filmList.get(6));
	    film.setLength((Integer) filmList.get(7));
		film.setReplacement_cost((Integer) filmList.get(8));
		film.setRating((Integer) filmList.get(9));
		film.setSpecial_features((String)filmList.get(10));
		Language language=new Language();
		language.setName((String) filmList.get(11));
	    film.setLanguage(language);
	    Category category=new Category();
		category.setName((String) filmList.get(12));
		film.setCategory(category);
		
		
		for(int i=13;i<filmList.size();i++)
		{
			Actor actor=new Actor();
			List actorDetails=(List) filmList.get(i);
			actor.setFirst_name((String) actorDetails.get(1));
			actor.setLast_name((String) actorDetails.get(2));
			film.getActor().add(actor);
		}
		filmDao.modifyFilm(film);
		return true;
		}
		else 
		return false;
	}
	public boolean removeFilm(int film_id)
	{
		return filmDao.removeFilm(film_id);
	}
	public Film searchFilm(int film_id) 
	{
		return filmDao.searchFilm(film_id);
	}
	public List<Film> getAllFilm()
	{
		return filmDao.getAllFilm();
	}
	
}
	



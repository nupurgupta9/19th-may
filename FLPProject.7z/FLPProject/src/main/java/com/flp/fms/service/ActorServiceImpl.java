package com.flp.fms.service;

import java.util.List;


import com.flp.ems.domain.Actor;
import com.flp.fms.dao.ActorDaoImplForList;

public class ActorServiceImpl implements IActorService
{
	 ActorDaoImplForList actorDao;
	 public ActorServiceImpl()
	 {
		actorDao=new ActorDaoImplForList();
	 }
	   
	   
	public Actor addActor(String first_name, String last_name)
	{
		Actor actor=new Actor();
		actor.setFirst_name(first_name);
		actor.setLast_name(last_name);
		return actorDao.addActor(first_name, last_name);
	}
	public Actor modifyActor(int actor_id, String firstname, String lastname)
	{
		Actor actor=actorDao.searchActor(actor_id);
		if(actor!=null)
		{
			actor.setFirst_name(firstname);
			actor.setLast_name(lastname);
		}
		return actor;
	}
	public boolean removeActor(int actor_id)
	{
		return actorDao.removeActor(actor_id);
	}
	public Actor searchActor(int actor_id)
	{
		return actorDao.searchActor(actor_id);
	}
	public List<Actor> getAllActor()
	{
		return actorDao.getAllActor();
	}

}

package com.flp.fms.view;

import java.text.ParseException;
import java.util.Scanner;

public class BootClass
{
	static Scanner scn=new Scanner(System.in);
	static UserInteraction ui=new UserInteraction();
	
	public static void main(String args[]) throws ParseException
	{	
		
		while(true)
		{
			System.out.println("Menu");
			System.out.print("1.AddFilm"+"\n"+"2.ModifyFilm"+"\n"+"3.RemoveFilm");
			System.out.print("\n"+"4.SearchFilm"+"\n"+"5.getAllFilm"+"\n");
			System.out.print("6.AddActor"+"\n"+"7.ModifyActor"+"\n"+"8.RemoveActor");
			System.out.print("\n"+"9.SearchActor"+"\n"+"10.getAllActor"+"\n"+"11.Exit"+"\n");
			System.out.print("Enter your Choice : ");
			int choice = scn.nextInt();
			menuSelection(choice);
		}
	}
	
	private static void menuSelection(int choice) throws ParseException
	{
		switch(choice)
		{
			case 1:ui.addFilm();
					break;
			case 2:ui.modifyFilm();
					break;
			case 3:ui.removeFilm();
					break;
			case 4:ui.searchFilm();
					break;
			case 5:ui.getAllFilm();
					break;
			case 6:ui.addActor();
					break;
			case 7:ui.modifyActor();
					break;
			case 8:ui.removeActor();
					break;
			case 9:ui.searchActor();
					break;
			case 10:ui.getAllActor();
					break;
			case 11:System.exit(0);
					break;
			default:System.out.println("Inavalid Menu Selection");
			break;
		}
	}
	
}
